// lib/screens/game_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';
import '../utils/storage_helper.dart';
import '../data/game_data.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  int _currentIndex = 0;
  int _score = 0;
  int _poinGame = 0;
  List<String> _selectedLetters = [];
  List<String> _availableLetters = [];
  List<String> _usedLetters = [];
  String _currentAnswer = '';
  bool _isAnswered = false;
  String? _feedbackMessage;
  bool? _isCorrect;

  late AnimationController _pulseCtrl;
  late AnimationController _bounceCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _pulseAnim;
  late Animation<double> _bounceAnim;
  late Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _resetPuzzle();

    _pulseCtrl = AnimationController(
        duration: const Duration(milliseconds: 1400), vsync: this)
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.04).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _bounceCtrl = AnimationController(
        duration: const Duration(milliseconds: 600), vsync: this);
    _bounceAnim =
        CurvedAnimation(parent: _bounceCtrl, curve: Curves.elasticOut);

    _shakeCtrl = AnimationController(
        duration: const Duration(milliseconds: 400), vsync: this);
    _shakeAnim = Tween<double>(begin: -8, end: 8).animate(
        CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn));
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _bounceCtrl.dispose();
    _shakeCtrl.dispose();
    super.dispose();
  }

  void _resetPuzzle() {
    final puzzle = gamePuzzles[_currentIndex];
    _selectedLetters = [];
    _usedLetters = [];
    _availableLetters = List.from(puzzle.availableLetters);
    _currentAnswer = '';
    _isAnswered = false;
    _feedbackMessage = null;
    _isCorrect = null;
    _updateCurrentAnswer();
  }

  void _selectLetter(String letter) {
    if (_isAnswered) return;
    setState(() {
      _selectedLetters.add(letter);
      _availableLetters.remove(letter);
      _usedLetters.add(letter);
      _updateCurrentAnswer();
    });
  }

  void _returnLetter(String letter) {
    if (_isAnswered) return;
    setState(() {
      _selectedLetters.remove(letter);
      _availableLetters.add(letter);
      _usedLetters.remove(letter);
      _updateCurrentAnswer();
    });
  }

  void _updateCurrentAnswer() {
    final puzzle = gamePuzzles[_currentIndex];
    String answer = '';
    for (int i = 0; i < puzzle.correctWord.length; i++) {
      String char = puzzle.correctWord[i];
      if (_selectedLetters.contains(char)) {
        answer += char;
      } else {
        answer += '_';
      }
    }
    _currentAnswer = answer;
  }

  void _checkAnswer() async {
    if (_isAnswered) return;

    final correct = _currentAnswer == gamePuzzles[_currentIndex].correctWord;

    setState(() {
      _isAnswered = true;
      _isCorrect = correct;
      if (correct) {
        _score++;
        _poinGame += 10;
        _feedbackMessage = 'Benar! +10 Poin';
        _bounceCtrl.forward(from: 0);
      } else {
        _feedbackMessage = 'Jawaban: ${gamePuzzles[_currentIndex].correctWord}';
        _shakeCtrl.forward(from: 0);
      }
    });

    Future.delayed(const Duration(seconds: 2), () {
      if (_currentIndex + 1 < gamePuzzles.length) {
        setState(() {
          _currentIndex++;
          _resetPuzzle();
        });
      } else {
        _selesaiGame();
      }
    });
  }

  Future<void> _selesaiGame() async {
    final storage = StorageHelper();
    int totalPoin = await storage.getTotalPoin();
    await storage.saveTotalPoin(totalPoin + _poinGame);

    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.2),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: const BoxDecoration(
                    color: AppColors.warningLight,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.emoji_events_rounded,
                      size: 44, color: AppColors.warning),
                ),
                const SizedBox(height: 16),
                Text(
                  'Game Selesai!',
                  style: GoogleFonts.poppins(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Skor: $_score / ${gamePuzzles.length}',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '+$_poinGame Poin',
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppColors.warning,
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.pop(context, true);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      'Kembali ke Menu',
                      style: GoogleFonts.poppins(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final puzzle = gamePuzzles[_currentIndex];
    final progress = (_currentIndex + 1) / gamePuzzles.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          // Header
          Container(
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.arrow_back_ios_rounded,
                                color: Colors.white, size: 16),
                          ),
                        ),
                        Expanded(
                          child: Center(
                            child: Text(
                              'Tebak Gambar',
                              style: GoogleFonts.poppins(
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.stars_rounded,
                                  color: AppColors.warning, size: 14),
                              const SizedBox(width: 4),
                              Text(
                                '$_poinGame Poin',
                                style: GoogleFonts.poppins(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: progress,
                              backgroundColor: Colors.white.withOpacity(0.25),
                              color: Colors.white,
                              minHeight: 7,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          '${_currentIndex + 1}/${gamePuzzles.length}',
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Image card
                  AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) => Transform.scale(
                      scale: _isAnswered ? 1.0 : _pulseAnim.value,
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.1),
                              blurRadius: 14,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(20)),
                              child: Image.asset(
                                puzzle.imageAsset,
                                height: 160,
                                width: double.infinity,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => Container(
                                  height: 160,
                                  color: AppColors.primaryPale,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(Icons.image_rounded,
                                          size: 48, color: AppColors.primary),
                                      const SizedBox(height: 8),
                                      Text(
                                        puzzle.imageHint,
                                        style: GoogleFonts.inter(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.primary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 12),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      'Gambar di atas adalah?',
                                      style: GoogleFonts.poppins(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.warningLight,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(Icons.lightbulb_rounded,
                                            size: 12,
                                            color: AppColors.warning),
                                        const SizedBox(width: 4),
                                        Text(
                                          puzzle.clue,
                                          style: GoogleFonts.inter(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.warning,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Answer display
                  AnimatedBuilder(
                    animation: _shakeCtrl,
                    builder: (_, __) => Transform.translate(
                      offset: Offset(
                          _isCorrect == false ? _shakeAnim.value : 0, 0),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: _isAnswered == false
                                ? AppColors.primary.withOpacity(0.2)
                                : _isCorrect == true
                                    ? AppColors.success.withOpacity(0.5)
                                    : AppColors.danger.withOpacity(0.5),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.06),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Jawaban: ',
                              style: GoogleFonts.inter(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            Text(
                              _currentAnswer.isEmpty
                                  ? '_ _ _ _'
                                  : _currentAnswer.split('').join(' '),
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 4,
                                color: _isCorrect == true
                                    ? AppColors.success
                                    : _isCorrect == false
                                        ? AppColors.danger
                                        : AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Selected letters
                  if (_selectedLetters.isNotEmpty) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.primaryPale,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Huruf Terpilih (ketuk untuk batal):',
                            style: GoogleFonts.inter(
                              fontSize: 11,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _selectedLetters.map((letter) {
                              return GestureDetector(
                                onTap: () => _returnLetter(letter),
                                child: _letterTile(letter,
                                    AppColors.warning, true),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // Available letters
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.center,
                    children: _availableLetters.map((letter) {
                      return GestureDetector(
                        onTap: _isAnswered
                            ? null
                            : () => _selectLetter(letter),
                        child: _letterTile(
                          letter,
                          _isAnswered
                              ? AppColors.textLight
                              : AppColors.primary,
                          !_isAnswered,
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 16),

                  // Check button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isAnswered || _currentAnswer.contains('_')
                          ? null
                          : _checkAnswer,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor: AppColors.inputBg,
                        disabledForegroundColor: AppColors.textLight,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text(
                        _isAnswered ? 'Memeriksa...' : 'Cek Jawaban',
                        style: GoogleFonts.poppins(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),

                  // Feedback
                  if (_feedbackMessage != null) ...[
                    const SizedBox(height: 12),
                    AnimatedBuilder(
                      animation: _bounceAnim,
                      builder: (_, child) => Transform.scale(
                        scale: _isCorrect == true
                            ? 0.95 + (_bounceAnim.value * 0.05)
                            : 1.0,
                        child: child,
                      ),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: _isCorrect == true
                              ? AppColors.successLight
                              : AppColors.dangerLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _isCorrect == true
                                ? AppColors.success.withOpacity(0.4)
                                : AppColors.danger.withOpacity(0.4),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _isCorrect == true
                                  ? Icons.check_circle_rounded
                                  : Icons.cancel_rounded,
                              color: _isCorrect == true
                                  ? AppColors.success
                                  : AppColors.danger,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _feedbackMessage!,
                                style: GoogleFonts.inter(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: _isCorrect == true
                                      ? AppColors.success
                                      : AppColors.danger,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _letterTile(String letter, Color color, bool active) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: active ? color : AppColors.inputBg,
        borderRadius: BorderRadius.circular(10),
        boxShadow: active
            ? [
                BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 3),
                )
              ]
            : [],
      ),
      child: Center(
        child: Text(
          letter,
          style: GoogleFonts.poppins(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: active ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
